const quizzes = {
    science: [
        { question: "What is the chemical symbol for water?", answers: ["H2O", "CO2", "O2", "NaCl"], correct: "H2O" },
        { question: "What planet is known as the Red Planet?", answers: ["Earth", "Mars", "Jupiter", "Venus"], correct: "Mars" },
        { question: "What is the powerhouse of the cell?", answers: ["Nucleus", "Mitochondrion", "Ribosome", "Golgi apparatus"], correct: "Mitochondrion" },
        { question: "Which gas do plants take in during photosynthesis?", answers: ["Oxygen", "Nitrogen", "Carbon dioxide", "Hydrogen"], correct: "Carbon dioxide" },
        { question: "What is the process by which plants make their food?", answers: ["Respiration", "Photosynthesis", "Transpiration", "Digestion"], correct: "Photosynthesis" },
        { question: "What is the main gas responsible for the greenhouse effect?", answers: ["Nitrogen", "Oxygen", "Carbon dioxide", "Argon"], correct: "Carbon dioxide" },
        { question: "Which of the following is a renewable resource?", answers: ["Oil", "Coal", "Solar energy", "Natural gas"], correct: "Solar energy" },
        { question: "What is the atomic number of Carbon?", answers: ["12", "6", "8", "10"], correct: "6" },
        { question: "Which scientist is credited with the theory of gravity?", answers: ["Albert Einstein", "Isaac Newton", "Marie Curie", "Nikola Tesla"], correct: "Isaac Newton" },
        { question: "What is the largest organ in the human body?", answers: ["Heart", "Liver", "Brain", "Skin"], correct: "Skin" },
    ],
    history: [
        { question: "Who was the first president of the USA?", answers: ["George Washington", "Thomas Jefferson", "Abraham Lincoln", "John Adams"], correct: "George Washington" },
        { question: "In which year did World War II end?", answers: ["1945", "1939", "1918", "1965"], correct: "1945" },
        { question: "Who was the leader of the Soviet Union during the Cuban Missile Crisis?", answers: ["Leonid Brezhnev", "Nikita Khrushchev", " Joseph Stalin", "Mikhail Gorbachev"], correct: "Nikita Khrushchev" },
        { question: "Who was the leader of the Soviet Union during the Cuban Missile Crisis?", answers: ["Leonid Brezhnev", "Nikita Khrushchev", " Joseph Stalin", "Mikhail Gorbachev"], correct: "Nikita Khrushchev" },
        { question: "Which ancient civilization built the pyramids in Egypt?", answers: ["Romans", "Greeks", "Egyptians", "Persians"], correct: "Egyptians" },
        { question: "Who was the famous queen of ancient Egypt?", answers: ["Cleopatra", "Nefertiti", "Hatshepsut", "Joan of Arc"], correct: "Cleopatra" },
        { question: "What event began on July 28, 1914?", answers: ["World War I", "The Great Depression", "The American Revolution", "The French Revolution"], correct: "World War I" },
        { question: "Which country was ruled by the Aztec Empire before its conquest by Spain?", answers: ["Peru", "Brazil", "Mexico", "Argentina"], correct: "Mexico" },
        { question: "What year did the Berlin Wall fall?", answers: ["1985", "1990", "1989", "1992"], correct: "1989" },
        { question: "Who was the leader of the Indian independence movement?", answers: ["Jawaharlal Nehru", "Mahatma Gandhi", "Subhas Chandra Bose", "Indira Gandhi"], correct: "Mahatma Gandhi" },
        { question: "Which of the following was the first manned moon landing mission?", answers: ["Apollo 13", "Apollo 11", "Apollo 15", "Apollo 7"], correct: "Apollo 11" }   
    ],
    geography: [
        { question: "What is the capital city of France?", answers: ["Paris", "Rome", "Madrid", "Berlin"], correct: "Paris" },
        { question: "Which continent is the Sahara Desert located in?", answers: ["Africa", "Asia", "North America", "Australia"], correct: "Africa" },
        { question: "What is the longest river in the world?", answers: ["Amazon River", "Nile River", "Yangtze River", "Mississippi River"], correct: "Nile River" },
        { question: "Which country has the most islands?", answers: ["Sweden", "Indonesia", "Canada", "Philippines"], correct: "Sweden" },
        { question: "Mount Everest is located in which two countries?", answers: ["Nepal and China", "India and China", "Nepal and India", "China and Bhutan"], correct: "Nepal and China" },
        { question: "What is the largest ocean on Earth?", answers: ["Atlantic Ocean", "Indian Ocean", "Arctic Ocean", "Pacific Ocean"], correct: "Pacific Ocean" },
        { question: "Which country is home to the Great Barrier Reef?", answers: ["South Africa", "New Zealand", "Australia", "Fiji"], correct: "Australia" },
        { question: "What is the smallest country in the world?", answers: ["Monaco", "Liechtenstein", "Vatican City", "San Marino"], correct: "Vatican City" },
        { question: "Which country is known as the Land of the Rising Sun?", answers: ["China", "Japan", "South Korea", "Thailand"], correct: "Japan" },
        { question: "Which U.S. state is famous for its volcanoes and earthquakes?", answers: ["California", "Hawaii", "Alaska", "Texas"], correct: "California" }
    ],
    moviesAndTV: [
        { question: "Who played Jack Dawson in Titanic?", answers: ["Leonardo DiCaprio", "Brad Pitt", "Johnny Depp", "Tom Cruise"], correct: "Leonardo DiCaprio" },
        { question: "What year was the first Star Wars movie released?", answers: ["1977", "1980", "1973", "1990"], correct: "1977" },
        { question: "In the TV show Friends, who was Ross's second wife?", answers: ["Carol", "Emily", "Susan", "Rachel"], correct: "Emily" },
        { question: "Which movie features the quote 'May the Force be with you'?", answers: ["Star Wars", "The Matrix", "Inception", "The Lord of the Rings"], correct: "Star Wars" },
        { question: "Who directed the movie 'Jurassic Park'?", answers: ["Steven Spielberg", "James Cameron", "George Lucas", "Ridley Scott"], correct: "Steven Spielberg" },
        { question: "Which actor played the character of Iron Man in the Marvel Cinematic Universe?", answers: ["Chris Hemsworth", "Robert Downey Jr.", "Mark Ruffalo", "Chris Evans"], correct: "Robert Downey Jr." },
        { question: "What is the name of the fictional African country in Black Panther?", answers: ["Wakanda", "Zamunda", "Elbonia", "Genovia"], correct: "Wakanda" },
        { question: "In which TV show would you find a character named Eleven?", answers: ["Stranger Things", "The Umbrella Academy", "Westworld", "The Walking Dead"], correct: "Stranger Things" },
        { question: "Which movie features a character named Forrest Gump?", answers: ["Forrest Gump", "The Green Mile", "Cast Away", "The Terminal"], correct: "Forrest Gump" },
        { question: "Who played the character of Hermione Granger in the Harry Potter films?", answers: ["Emma Watson", "Rupert Grint", "Daniel Radcliffe", "Bonnie Wright"], correct: "Emma Watson" }
    ],
    music: [
        { question: "Who is known as the King of Pop?", answers: ["Elvis Presley", "Michael Jackson", "Prince", "James Brown"], correct: "Michael Jackson" },
        { question: "Which band released the album 'Abbey Road'?", answers: ["The Rolling Stones", "The Beatles", "Pink Floyd", "Led Zeppelin"], correct: "The Beatles" },
        { question: "What is the name of the famous music festival held annually in California?", answers: ["Coachella", "Lollapalooza", "Glastonbury", "Woodstock"], correct: "Coachella" },
        { question: "Which singer's real name is Stefani Joanne Angelina Germanotta?", answers: ["Ariana Grande", "Lady Gaga", "Katy Perry", "Beyoncé"], correct: "Lady Gaga" },
        { question: "Which classical composer wrote 'The Four Seasons'?", answers: ["Ludwig van Beethoven", "Johann Sebastian Bach", "Wolfgang Amadeus Mozart", "Antonio Vivaldi"], correct: "Antonio Vivaldi" },
        { question: "What year did Michael Jackson release 'Thriller'?", answers: ["1980", "1982", "1984", "1986"], correct: "1982" },
        { question: "Which band is famous for the song 'Bohemian Rhapsody'?", answers: ["The Beatles", "Queen", "The Rolling Stones", "Led Zeppelin"], correct: "Queen" },
        { question: "Who is known for the hit song 'Shape of You'?", answers: ["Ed Sheeran", "Justin Bieber", "Drake", "Kendrick Lamar"], correct: "Ed Sheeran" },
        { question: "Which famous singer was known as 'The Queen of Soul'?", answers: ["Aretha Franklin", "Whitney Houston", "Etta James", "Diana Ross"], correct: "Aretha Franklin" },
        { question: "Which 90s boy band was known for songs like 'I Want It That Way'?", answers: ["Backstreet Boys", "NSYNC", "98 Degrees", "O-Town"], correct: "Backstreet Boys" }
    ],
    sports: [
        { question: "Who holds the record for the most goals scored in a single World Cup?", answers: ["Pele", "Marta", "Miroslav Klose", "Just Fontaine"], correct: "Just Fontaine" },
        { question: "Which country hosted the 2016 Summer Olympics?", answers: ["China", "United States", "Brazil", "Russia"], correct: "Brazil" },
        { question: "In what sport would you perform a slam dunk?", answers: ["Basketball", "Football", "Tennis", "Baseball"], correct: "Basketball" },
        { question: "Which country is the birthplace of rugby?", answers: ["Australia", "New Zealand", "South Africa", "England"], correct: "England" },
        { question: "Who won the 2020 NBA MVP award?", answers: ["LeBron James", "Giannis Antetokounmpo", "James Harden", "Kawhi Leonard"], correct: "Giannis Antetokounmpo" },
        { question: "In which sport do athletes compete in a decathlon?", answers: ["Track and Field", "Gymnastics", "Swimming", "Cycling"], correct: "Track and Field" },
        { question: "Which tennis player has won the most Grand Slam singles titles?", answers: ["Roger Federer", "Rafael Nadal", "Novak Djokovic", "Pete Sampras"], correct: "Rafael Nadal" },
        { question: "In which year did the Chicago Cubs win the World Series after a 108-year drought?", answers: ["2016", "2014", "2012", "2018"], correct: "2016" },
        { question: "Who holds the record for the most home runs in Major League Baseball history?", answers: ["Babe Ruth", "Barry Bonds", "Hank Aaron", "Ken Griffey Jr."], correct: "Barry Bonds" },
        { question: "Which country won the 2018 FIFA World Cup?", answers: ["France", "Germany", "Brazil", "Argentina"], correct: "France" }
  ],
    artAndLiterature: [
        { question: "Who painted the Mona Lisa?", answers: ["Vincent van Gogh", "Leonardo da Vinci", "Pablo Picasso", "Claude Monet"], correct: "Leonardo da Vinci" },
        { question: "Which playwright wrote 'Romeo and Juliet'?", answers: ["William Shakespeare", "Oscar Wilde", "George Bernard Shaw", "Tennessee Williams"], correct: "William Shakespeare" },
        { question: "Which novel begins with the line 'Call me Ishmael'?", answers: ["Moby-Dick", "Pride and Prejudice", "The Catcher in the Rye", "The Great Gatsby"], correct: "Moby-Dick" },
        { question: "Who is the author of the 'Harry Potter' series?", answers: ["J.K. Rowling", "J.R.R. Tolkien", "George R.R. Martin", "C.S. Lewis"], correct: "J.K. Rowling" },
        { question: "Which artist is known for his 'Starry Night' painting?", answers: ["Claude Monet", "Salvador Dalí", "Vincent van Gogh", "Pablo Picasso"], correct: "Vincent van Gogh" },
        { question: "Who wrote 'The Picture of Dorian Gray'?", answers: ["Oscar Wilde", "F. Scott Fitzgerald", "Jane Austen", "Mark Twain"], correct: "Oscar Wilde" },
        { question: "Which sculpture is often associated with Ancient Greece?", answers: ["The Thinker", "David", "The Statue of Liberty", "Venus de Milo"], correct: "Venus de Milo" },
        { question: "Who is the author of the 'Lord of the Rings' trilogy?", answers: ["George R.R. Martin", "J.R.R. Tolkien", "C.S. Lewis", "J.K. Rowling"], correct: "J.R.R. Tolkien" },
        { question: "Which famous artist is known for his works such as 'Guernica'?", answers: ["Pablo Picasso", "Michelangelo", "Leonardo da Vinci", "Salvador Dalí"], correct: "Pablo Picasso" },
        { question: "In which book would you find the character Atticus Finch?", answers: ["To Kill a Mockingbird", "The Great Gatsby", "1984", "The Catcher in the Rye"], correct: "To Kill a Mockingbird" }
  ],
    technology: [
        { question: "Who is the co-founder of Microsoft?", answers: ["Steve Jobs", "Bill Gates", "Mark Zuckerberg", "Elon Musk"], correct: "Bill Gates" },
        { question: "What does the acronym 'HTTP' stand for?", answers: ["HyperText Transmission Protocol", "HyperText Transfer Protocol", "HyperText Transport Protocol", "HyperTransfer Text Protocol"], correct: "HyperText Transfer Protocol" },
        { question: "What year was the first iPhone released?", answers: ["2007", "2005", "2010", "2009"], correct: "2007" },
        { question: "Which company developed the Android operating system?", answers: ["Apple", "Microsoft", "Google", "Samsung"], correct: "Google" },
        { question: "What does the acronym 'USB' stand for?", answers: ["Universal System Bus", "Universal Serial Bus", "Universal Service Bus", "Unified Service Bus"], correct: "Universal Serial Bus" },
        { question: "Which programming language is known as the 'mother of all languages'?", answers: ["Python", "C", "Java", "Assembly"], correct: "C" },
        { question: "Who is the CEO of Tesla?", answers: ["Elon Musk", "Jeff Bezos", "Mark Zuckerberg", "Bill Gates"], correct: "Elon Musk" },
        { question: "Which company first developed the personal computer?", answers: ["IBM", "Apple", "Microsoft", "Compaq"], correct: "Apple" },
        { question: "What year did the World Wide Web become publicly available?", answers: ["1990", "1985", "2000", "1995"], correct: "1990" },
        { question: "Which technology is used to make cryptocurrency transactions secure?", answers: ["Blockchain", "Cloud Computing", "Artificial Intelligence", "Quantum Computing"], correct: "Blockchain" }
  ]
};

function takeRandomQuiz() {
    // gets selected category
    const category = document.getElementById("category").value;

    // gets the questions for the selected category
    const questions = quizzes[category];

    // randomly selects a question
    const randomIndex = Math.floor(Math.random() * questions.length);
    const selectedQuestion = questions[randomIndex];

    // displays the question and answers
    document.getElementById("question").textContent = selectedQuestion.question;

    // creates the answer options
    const answersList = document.getElementById("answers");
    answersList.innerHTML = ""; // clears any previous answers
    selectedQuestion.answers.forEach(answer => {
        const li = document.createElement("li");
        li.textContent = answer;
        li.addEventListener("click", () => selectAnswer(answer, selectedQuestion.correct));
        answersList.appendChild(li);
    });
}

function selectAnswer(selectedAnswer, correctAnswer) {
    if (selectedAnswer === correctAnswer) {
        alert("Correct!");
    } else {
        alert("Incorrect! The correct answer is " + correctAnswer);
    }

    // calls takeRandomQuiz again to load a new question
    takeRandomQuiz();
}

